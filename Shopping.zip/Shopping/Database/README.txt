1. Import the database on you xammpp MySQL database
2. Extract the mysql-connection in your prefered folder 
3. add library and add the mysql jar may logo yan sya pag na extract mo na yung file
pag di mo nakita create ka new library tapos naka path dapat sa na extract mo at sa laman ng na extract mo class and source nya yan same lang
 


Thank You!!!!